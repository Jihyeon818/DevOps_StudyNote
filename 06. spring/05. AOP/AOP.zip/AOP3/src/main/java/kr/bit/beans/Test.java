package kr.bit.beans;

import org.springframework.stereotype.Component;

@Component
public class Test {
	public void m1() {
		System.out.println("m1");
	}
}
