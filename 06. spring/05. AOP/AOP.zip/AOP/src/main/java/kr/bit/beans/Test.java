package kr.bit.beans;

public class Test {
	public int Test() {
		System.out.println("test");
		return 10;
	}	
}
