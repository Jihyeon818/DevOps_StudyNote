package kr.bit.beans2;

public class Test {
	public void m1() {
		System.out.println("beans2 test m1");
	}
}
