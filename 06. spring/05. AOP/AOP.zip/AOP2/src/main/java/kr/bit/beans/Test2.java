package kr.bit.beans;

public class Test2 {
	
	public void m1() {
		System.out.println("test2 m1");
	}
}
